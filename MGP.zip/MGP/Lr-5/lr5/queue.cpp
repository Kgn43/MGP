#include "funks.h"


string talonGen(){
    string res;
    res.push_back(rand()%32 + 'A');
    for (int i = 0; i < 3; i++){
        res.push_back(rand()%10 + '0');
    }
    return res;
}


uint32_t minInLine(vector<pair<int, vector<string>>> windows){
uint32_t min = 0;
for (uint32_t i = 0; i < windows.size(); i++){
if (windows[i].first < windows[min].first) min = i;
}
return min;

}


uint32_t timeForLine(vector<pair<string, uint32_t>> &peoples){
    uint32_t time = 0;
    for (const auto& i : peoples){
        time += i.second;
    }
    return time;
}


void queue(){
    uint32_t window;
    cout << ">>> Enter the number of windows" << endl << "<<< ";
    cin >> window;
    string command = " ";
    string talon;
    vector<pair<string, uint32_t >> peoples;
    while (command != "distribute"){
        if (command == " "){
            getline(cin, command);
            continue;
        }
        cout << "<<< ";
        getline(cin, command);
        if (!command.find("enqueue")){ //��� �������, ��������� find ������ ������, � ���� �����, �� ������ 0, ����� uint_max
            command.erase(0, command.find(' '));
            talon = talonGen();
            peoples.emplace_back(talon, stoi(command));
            cout << ">>> " << talon << endl;
        }
    }
    for (const auto& i : peoples){
        cout << i.first << " " << i.second << endl;
    }
    vector<pair<int, vector<string>>> windows;
    windows.reserve(window);
    for (auto i = 0; i < window; i++){
        windows.push_back({0, {" "}});
    }
    uint32_t time = timeForLine(peoples) / window;
    cout << time << endl;
    uint32_t minInL = 0;
    vector<pair<int, string>> peoples2;
    peoples2.reserve(peoples.size());
    for (const auto& i : peoples){
        peoples2.emplace_back(i.second, i.first);
    }
    sort(peoples2.begin(), peoples2.end(), [](auto people1, auto people2){
        return people1 > people2;
    });

    for (const auto &i: peoples2){
        minInL = minInLine(windows);
        windows[minInL].first += i.first;
        windows[minInL].second.push_back(i.second);
    }
    window = 0;
    for (const auto& i : windows){
        cout << "Window " << window << " (" << i.first << " min)" << ":";
        for (const auto& j: i.second){
            cout << j << " ";
        }
        cout << endl;
        ++window;
    }
}