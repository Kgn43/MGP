#include "funks.h"


enum cmd{
    key = 0,
    obj = 1
};


void displayTowns(map<string, vector<string>> &mp){
    for (const auto& i : mp) {
        cout << i.first << ": ";
        for (const auto& j : i.second){
            cout << j << " ";
        }
        cout << endl;
    }
}


void displayOneTown(map<string, vector<string>> &towns, vector<string> &command){
    if (command.size() > 1){
        cout << command[cmd::obj] << ": ";
        for(const auto& i : towns[command[cmd::obj]]){
            cout << i << " ";
        }
        cout << endl;
    }
    else {
        cout << "Wrong command" << endl;
    }
}


void displayOneTrain(map<string, vector<string>> &trains, vector<string> &command, map<string, vector<string>> &towns){
    if (command.size() > 1){
        cout << command[cmd::obj] << ": ";
        for(const auto& i : trains[command[cmd::obj]]){
            cout << i << ": " << endl;
            for(auto j : towns[i]){
                cout << j << " ";
            }
            cout << endl;
        }
        cout << endl;
    }
    else {
        cout << "Wrong command" << endl;
    }
}


void trains(){
    map<string, vector<string>> towns; //������ �������
    map<string, vector<string>> trains; //������ �������
    vector<string> command; //������� �������
    string input = " ";//���������������� ����
    string inputPart;
    while (true){
        command.clear();
        if (input == " "){//������ �������� ����� �������, ��������� ������ -1073741819
            getline(cin, input);
            continue;
        }
        cout << "Enter command" << endl;
        getline(cin, input);
        stringstream ss(input);
        while (ss >> inputPart){
            command.push_back(inputPart);
        }
        if (command[cmd::key] == "exit") {
            break;
        }
        if(command[cmd::key] == "towns"){
            displayTowns(towns);
        }
        if (command[cmd::key] == "trains_for_town"){
            displayOneTown(towns, command);
        }
        if (command[cmd::key] == "towns_for_train"){
            displayOneTrain(trains, command, towns);
        }
        if (command[cmd::key] == "create_train"){
            if (command.size() <= 3 || command[2] == command[3] && command.size() == 4 ) {
                cout << "Wrong command" << endl;
                continue;
            }
            if (!trains[command[cmd::obj]].empty()){
                cout << "That train already exist" << endl;
                continue;
            }
            copy(command.begin() + 2, command.end(), back_inserter(trains[command[cmd::obj]]));
            for(auto i = 2; i != command.size(); i++){
                towns[command[i]].push_back(command[cmd::obj]);
            }
        }
    }
}