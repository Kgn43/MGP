#ifndef LR5_FUNKS_H
#define LR5_FUNKS_H

using namespace std;

#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <sstream>
#include <algorithm>


void accounting();
void queue();
void trains();
void friendship();

#endif //LR5_FUNKS_H
