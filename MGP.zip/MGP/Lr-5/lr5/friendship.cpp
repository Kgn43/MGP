#include "funks.h"


bool theyIsFriends (const vector<pair<string, string>> &friendsList, const vector<string> &command){
    return find_if(friendsList.begin(), friendsList.end(), [command](const auto &friendsNew){
        return friendsNew == make_pair(command[2], command [1]) || friendsNew == make_pair(command[1], command [2]);
    }) != friendsList.end();
}


vector<pair<string, string>> friendsCommand(vector<pair<string, string>> &friendsList,const vector<string> &command){
    if (command.size() == 3 && command[1] != command [2]){
        if (!theyIsFriends(friendsList,command) ){
            friendsList.emplace_back(command[1], command [2]);
        } else {
            cout << "They already friends" << endl;
        }
    } else {
        cout << "error in \"friends\" command" << endl;
    }
    return friendsList;
}


void countCommand(vector<pair<string, string>> &friendsList,const vector<string> &command){
    uint32_t friendsCount = 0;
    if (command.size() == 2){
        for (const auto &i : friendsList){
            if (i.first == command[1] || i.second == command[1]) friendsCount++;
        }
        cout << command[1] << " has " << friendsCount << " friends" << endl;
    }
    else {
        cout << "error in \"count\" command" << endl;
    }
}


void questionCommand(vector<pair<string, string>> &friendsList,const vector<string> &command){
    if (command.size() == 3 && command[1] != command [2]){
        if (theyIsFriends(friendsList, command)){
            cout << "Yes" << endl;
        }
        else{
            cout << "No" << endl;
        }
    } else {
        cout << "error in \"question\" command" << endl;
    }
}


void friendship(){
    cout << "Enter the number of requests: ";
    int n;
    cin >> n;
    vector<string> command; //������� �������
    string input = "firstStep";//���������������� ����
    string inputPart;//����� �������
    vector<pair<string, string>> friendsList;
    while(n){
        if (input == "firstStep"){//������ �������� ����� �������, ��������� ������ -1073741819
            getline(cin, input);
            continue;
        }
        getline(cin, input);
        stringstream ss(input);
        while (ss >> inputPart){
            command.push_back(inputPart);
        }
        if (command[0] == "friends"){
            friendsList = friendsCommand(friendsList, command);
        }
        if (command[0] == "count"){
            countCommand(friendsList, command);
        }
        if (command[0] == "question"){
            questionCommand(friendsList, command);
        }
        command.clear();
        --n;
    }
}