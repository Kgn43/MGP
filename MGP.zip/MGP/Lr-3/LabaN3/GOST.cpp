#include "funcs.h"


template <typename T>
ostream& operator<<(ostream& os, vector<T> vec){
    for (T i : vec){
        os<< i << "\t|\t";
    }
    return os;
}


int gost341094(const int q, int t){
    int n;
    int u;
    int p;
    bool isPrime = false;
    double e;
    do{
        e = rand();
        while (e > 1){
            e /= 10;
        }
        n = static_cast<int>(round(pow(2, t-1)/q) + round((pow(2,t-1) * e) / q));
        if (n % 2 == 1){
            ++n;
        }
        u = 0;
        while (!isPrime){
            p = (n + u) * q + 1;
            if (p > pow(2, t)){
                break;
            }
            if (powMod(2, p-1, p) == 1 && powMod(2, n+u, p) != 1){
                isPrime = true;
            }
            else{
                u += 2;
            }
        }
    }
    while(!isPrime);
    return p;
}


void F5(int t){
    vector<int> sieve;
    sieve = simplNumsMake(sieve);
    vector<int> primeNums; //������ �������
    vector<bool> primeTestAgree; //�������� �� ������������� ���� �������?
    int q;
    for (int g = 0; g < 10; g++){
        q = sieve[rand()%(sieve.size())];
        q = gost341094(q, t);
        primeNums.push_back(q);
        primeTestAgree.push_back(probabTest(q));
    }
    cout << endl << "|\t";//����� ������� � �������
    for (int i = 1; i <= 10; i++){
        cout << i << "\t|\t";
    }
    cout << endl << "|\t";
    cout << primeNums << endl << "|\t" << boolalpha << primeTestAgree << endl;
}

