#ifndef LABAN3_FUNCS_H
#define LABAN3_FUNCS_H

#include <vector>
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

void F1();
void out(double xSt, double xEnd, double dX);

void F2();
vector<int> simplNumsMake(vector<int> &simplNums);

void F3(int t = 6);
bool probabTest(int num, int k = 3);
bool MillerTest(int n, int t);
bool generalTest(int n, vector<int> &randNums, int t);

void F4(int t = 6);
int bitLen(int number);
bool oneBit(int m, int r);

void F5(int t = 15);
int gost341094(int q, int t);

void F6();

int evclSmpl(int num1, int num2);
int euler(int m);
bool primeCheck(int num);
int powMod(int base, int degree, int mod);
vector<pair<int, int>> canonicalDecomposition(vector <pair<int, int>> &factors, int n);
#endif //LABAN3_FUNCS_H
