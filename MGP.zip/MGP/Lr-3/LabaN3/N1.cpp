#include "funcs.h"

void out(double xSt, double xEnd, double dX){
    double x = xSt, y;
    cout << "---------------------------------" << endl << "|\tx\t|\ty\t|" << endl;
    cout << "---------------------------------" << endl;
    while (x <= xEnd){
        if (x > xEnd){
            x = xEnd;
        }
        if (x <= -3){
            y = x + 3;
        }
        if (x > -3 && x < 0){
            y = sqrt(9-pow(x,2));
        }
        if (x >= 0 && x < 6){
            y = 3 - x/2;
        }
        if (x >= 6){
            y = x - 6;
        }
        cout << "|\t" << fixed << setprecision(3) << x << "\t|\t" << y <<"\t|" << endl;
        x += dX;
    }
    cout << "---------------------------------" << endl;


}


void F1(){
    double xSt, xEnd, dX;
    cout << "Enter X start" << endl;
    cin >> xSt;
    cout << "Enter X end" << endl;
    cin >> xEnd;
    cout << "Enter dX " << endl;
    cin >> dX;
    out(xSt, xEnd, dX);
}
