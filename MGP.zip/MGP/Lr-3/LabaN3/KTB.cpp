#include "funcs.h"


void cofe(double Tk, double Tsr, double r, int time, vector<double> &Yt){ //x �������� �� 0 �� time � �������� � dx = 1
    for (int i = 0; i < time; i++) {
        Yt.push_back(Tk);
        Tk -= r * (Tk - Tsr);
    }
}


pair<double, double> aprox (vector<double> &Yt, int n){
    double summ1 = 0;
    double summ2 = 0;
    double summ3 = 0;
    double summ4 = 0;
    for (int x = 0; x < n; x++){
        summ1 += x * Yt[x];
        summ2 += x;
        summ3 += Yt[x];
        summ4 += x * x;
    }
    double a = (n * summ1 - summ2 * summ3) / (n * summ4- summ2 * summ2);
        double b = (summ3 - a * summ2) / n;
    return {a,b};
}


double korell(vector<double> &Yt, int n){
    int summX = 0;
    double summY = 0.0;
    for (int x = 0; x < n; x++){
        summX += x;
        summY += Yt[x];
    }
    double Xm = static_cast<double>(summX) / n;
    double Ym = static_cast<double>(summY) / n;
    double summ1 = 0;
    double summ2 = 0;
    double summ3 = 0;
    for (int x = 0; x < n; x++){
        summ1 += (x - Xm) * (Yt[x] - Ym);
        summ2 += (x - Xm) * (x - Xm);
        summ3 += (Yt[x] - Ym) * (Yt[x] - Ym);
    }
   // cout << summ1 << " " << summ2 << " " << summ3 << endl;
    double r = summ1 / sqrt(summ2 * summ3);
    return r;
}


void F6(){
    double Tk;
    cout << "Enter the coffee temperature: ";
    cin >> Tk;
    double Tsr;
    cout << "Enter the ambient temperature: ";
    cin >> Tsr;
    double r;
    cout << "Enter the cooling factor: ";
    cin >> r;
    int time;
    cout << "Enter the time: ";
    cin >> time;
    vector<double> Yt;
    cofe(Tk, Tsr, r, time, Yt);
    cout << "---------------------------------" << endl << "|  time\t| temperature\t|" << endl;
    cout << "---------------------------------" << endl;
    for (int x = 0; x < time; x++){
        cout << "|\t" << setprecision(3) << x << "\t|\t" << Yt[x] << "\t|" << endl;
    }
    cout << "---------------------------------" << endl;
    pair<double, double> apr = aprox(Yt, time);
    cout << "approximating straight line: " << endl << "y = " << setprecision(2) << apr.first << " * x + " << apr.second << endl;
    double R = korell(Yt, time);
    cout << "correlation coefficient: " << R << endl;
}