#include <iostream>
#include <random>
#include <chrono>
#include <algorithm>
#include <fstream>

using namespace std;

template <typename T>
ofstream & operator<<(ofstream & os, vector<vector<T>> vec){
    os << endl;
    for (const auto& i : vec){
        for (const T& j : i){
            os << j << " ";
        }
        os << endl;
    }
    return os;
}


int generator(int min, int max){
    mt19937 rndGen (chrono::system_clock::now().time_since_epoch().count());
    uniform_int_distribution  distribution (min, max);
    return distribution(rndGen);
}


vector<vector<int>> makeNeo(vector<vector<int>> &neo, uint32_t strSize, uint32_t columnSize, int min, int max){
    neo.reserve(columnSize);
    generate_n(back_inserter(neo),columnSize, [strSize, min, max] (){
        vector<int> str;
        str.reserve(strSize);
        generate_n(back_inserter(str), strSize, [min, max]() {return generator(min, max);});
        return str;
    });
    return neo;
}


void displayMatrix(const vector<vector<int>> &neo){
    for (const auto& i : neo){
        for (auto j : i){
            cout << j << "\t";
        }
        cout << endl;
    }
    cout << endl;
}


vector<vector<int>> subMatrixMake(vector<vector<int>> &matrix){
    uint32_t columnSize = matrix.size();
    uint32_t strSize = matrix[1].size();
    for (auto i = 0; i < columnSize - 1; i++) {
        for (auto j = 0; j < strSize - 1; j++) {
            if(matrix[i][j] == 1 && matrix[i+1][j] == 1 && matrix[i][j+1] == 1 && matrix[i+1][j+1] == 1 ){
                matrix[i][j] = 1;
            } else {
                matrix[i][j] = 0;
            }
        }
    }
    for (auto &str : matrix){
        str.erase(str.end()-1);
    }
    matrix.erase(matrix.end()-1);
    return matrix;
}


uint32_t subMatrixCountFunc(vector<vector<int>> &matrix){
    uint32_t result = 0;
    for (const auto &i : matrix){
        for (const auto j : i){
            if (j == 1) result++;
        }
    }
    return result;
}


void number1() {
    // 1
    vector<vector<int>> matrix;
    uint32_t size = 10;
    matrix = makeNeo(matrix, size, size, -50, 50);
    displayMatrix(matrix);
    for (auto &i : matrix){
        for (auto j = 1; j < size; j += 2){
            if (i[j] >= -10 && i[j] <= 10) i[j] = 11;
        }
    }
    displayMatrix(matrix);
    //2
    matrix.clear();
    cout << "Enter string len" << endl;
    uint32_t strSize;
    cin >> strSize;
    cout << "Enter column len" << endl;
    uint32_t columnSize;
    cin >> columnSize;
    matrix = makeNeo(matrix, strSize, columnSize, -100, 100);
    displayMatrix(matrix);
    int positiveCount = 0;
    for (auto i = 0; i < strSize; i++){
        for (auto j = 0; j < columnSize; j++){
            if (matrix[j][i] > 0) positiveCount++;
        }
        if (2 * positiveCount > columnSize){
            for(auto j = 0; j < columnSize / 2; j++){
                for (int k = 0, cup; k < columnSize / 2 - 1; k++){
                    if(matrix[k][i] > matrix[k+1][i]){
                        cup = matrix[k][i];
                        matrix[k][i] = matrix[k+1][i];
                        matrix[k+1][i] = cup;
                    }
                }
            }
        } else if (2 * positiveCount < columnSize){
            for (auto j = 0; j < columnSize; j++){
                matrix[j][i] = matrix[j][i] * matrix[j][i];
            }
        } else {
            for (auto j = 0; j < columnSize; j++){
                matrix[j][i] = 0;
            }
        }
        positiveCount = 0;
    }
    displayMatrix(matrix);
    //3
    ofstream output;
    output.open("table.txt");
    if (output.is_open()){
        vector<vector<int>> example = {
                {0, 1, 1, 1, 1, 0, 0},
                {1, 1, 1, 1, 1, 1, 1},
                {0, 0, 1, 1, 1, 1, 0},
                {0, 0, 0, 1, 1, 1, 1}
        };
        matrix.clear();
        matrix = makeNeo(matrix, strSize, columnSize, 0,1);
        {
            matrix = example;
            strSize = 7;
            columnSize = 4;
        }
        displayMatrix(matrix);
        uint32_t squareSize = 1;
        uint32_t totalSubMatrix = 0;
        uint32_t subMatrixCount;
        while(squareSize <= columnSize && squareSize <= strSize ){
            subMatrixCount = subMatrixCountFunc(matrix);
            output << matrix;
            matrix = subMatrixMake(matrix);
            totalSubMatrix += subMatrixCount;
            cout << subMatrixCount << " subMatrix with side " << squareSize++ << "," << endl;
        }
        cout << "Total " << totalSubMatrix << " subMatrix found" << endl;
    }
    output.close();

}

