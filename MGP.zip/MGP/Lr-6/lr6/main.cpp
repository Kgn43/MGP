#include "connection.h"





int main() {
    int n;
    cout << "Choose mode: ";
    cin >> n;
    switch (n) {
        case 1:
            number1();
            break;
        case 2:
            AES();
            break;
        case 3:
            slau();
            break;
        default:
            cout << "Incorrect input" << endl;
    }
    return 1;
}
