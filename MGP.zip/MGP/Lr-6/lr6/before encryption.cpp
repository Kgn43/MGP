#include "connection.h"

void inputToFile(string &senderFile){
    ofstream out; //����� ������ � ����
    out.open(senderFile);
    if (out.is_open()){ //���� ���� ���������� � �����������
        string str;
        while (getline(cin, str)){
            if (str == "EOF" || str.empty()) break; //���� �� ����� � ������� EOF
            out << str << '\n';
        }
    }
    out.close();
}


string fileToStr(string &str, string &senderFile){
    ifstream in;
    in.open(senderFile);
    if(in.is_open()){
        char ch;
        while(in.get(ch)){
            str.push_back(ch);
        }
    }
    in.close();
    return str;
}


vector<unsigned char> strToVec(string &input){
    vector<unsigned char> output;
    output.reserve(input.size());
    for (auto i : input){
        output.push_back(static_cast<unsigned char>(i));
    }
    return output;
}


vector<vector<unsigned char>> massageToBlocks(const vector<unsigned char> &massage){
    vector<vector<unsigned char>> output;
    vector<unsigned char> tmp;
    for (int i = 0; 16 * i < massage.size(); i++){
        for (int j = 0; j < 16; j++){
            if (16*i + j < massage.size()){
                tmp.push_back(massage[j + 16 * i]);
            }
            else{
                tmp.push_back(' ');
            }
        }
        output.push_back(tmp);
        tmp.clear();
    }
    return output;
}