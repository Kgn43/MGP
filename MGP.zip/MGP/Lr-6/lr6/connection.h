//
// Created by kagan on 26.05.2024.
//

#ifndef LR6_CONNECTION_H
#define LR6_CONNECTION_H

#include <iostream>
#include <fstream>
#include <vector>
#include <random>
#include <chrono>
#include <algorithm>
#include <iomanip>

using namespace std;

void inputToFile(string &senderFile);
string fileToStr(string &str, string &senderFile);
vector<unsigned char> strToVec(string &input);
vector<vector<unsigned char>> massageToBlocks(const vector<unsigned char> &massage);
void AES();
void number1();
void slau();

#endif //LR6_CONNECTION_H
